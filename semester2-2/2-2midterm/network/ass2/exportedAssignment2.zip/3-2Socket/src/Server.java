import java.io.*;
import java.net.*;

public class Server {
	
	
	static ServerSocket welcomeSocket;
	
	
	public static void main(String[] args) throws Exception {
		
		Server s = new Server();
		String host = "";
		int port = 0;
		
		BufferedReader br = new BufferedReader(new FileReader("./serverinfo.txt"));	//read ip and port number
	    while(true) {
	    	String line = br.readLine();
	        if (line==null) {
	        	break;}
	            
	        String[] twowords = line.split(" ");	//split by ' '
	        host = twowords[0];					//ip number
	        port = Integer.parseInt(twowords[1]);	//port number
	    }
	    Bank bank = new Bank();
	    bank.setnew();
	    welcomeSocket = new ServerSocket(port);	//welcomeSocket at port
	    while(true) {
	    	Socket client = welcomeSocket.accept();	//wait, on welcoming socket for contact by client
	    	ClientHandler handler = new ClientHandler(client, bank);	//make a ClientHandler object
	
	    	Thread thread = new Thread(handler);	//create a thread
			
	    	thread.start();//start execution of the thread
	    }
		
	}
	
}

