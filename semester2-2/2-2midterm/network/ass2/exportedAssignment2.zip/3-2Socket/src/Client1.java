import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.*;

public class Client1 {
	static Socket clientSocket;
	public static void main(String argv[]) throws Exception{
		/************************************
		 
		  	CHECK "name"
			DEPOSIT "name" amount
			WITHDRAW "name" amount
			TRANSFER "name1" amount "name2"

		 ************************************/
		
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		//create input stream
		String host = "";
		int port = 0;
		
		BufferedReader br = new BufferedReader(new FileReader("./serverinfo.txt"));	//read serverinfo.txt
        while(true) {
            String hostport = br.readLine();
            if (hostport==null) break;	//nothing read
            
            String[] linebuffer = hostport.split(" ");	//split by " " and save in linebuffer
            host = linebuffer[0];					//host has linebuffer[0]
            port = Integer.parseInt(linebuffer[1]);	//port has linebuffer[1] in int
        }
        
		// read host and port from the file
		
        /*stay in loop so that it sends given data by */
		while(true) {
			clientSocket = new Socket(host, port);	//create client socket and connect to server
			
			DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
			//create output stream attacked to socket
			BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			//create input stream attacked to socket
			String sentence = inFromUser.readLine();	//read from user]
			if(sentence.equalsIgnoreCase("q")) {
				System.exit(0);
			}
			outToServer.writeBytes(sentence + "\n");	//send line to server
			
			String modifiedSentence = inFromServer.readLine();	//read line from server
			modifiedSentence = modifiedSentence.toString();
			
			if(modifiedSentence.contains("EXCEPTION")) {	//if modifiedSentence contains EXCEPTION
				modifiedSentence = modifiedSentence.replaceAll("EXCEPTION: ", "Error message : ");
			}
			else if (modifiedSentence.contains("C1")) {		//if modifiedSentence contains C1
				modifiedSentence = modifiedSentence.replaceAll("C1 ", "");
				modifiedSentence = modifiedSentence.replaceAll("ACCEPT", "NOW HAS ");
			}
			else if (modifiedSentence.contains("C0")) {		//if modifiedSentence contains C0
				modifiedSentence = modifiedSentence.replace("C0 ", "");
				modifiedSentence = modifiedSentence.replace("ACCOUNT FOUND", "HAS ");
				
			}
			else if (modifiedSentence.contains("C2")) {		//if modifiedSentence contains C2
				modifiedSentence = modifiedSentence.replaceAll("C2 ", "");
				modifiedSentence = modifiedSentence.replaceAll("ACCEPT", "NOW HAS ");
			}
			else if (modifiedSentence.contains("C3")) {		//if modifiedSentence contains C3
				modifiedSentence = modifiedSentence.replaceAll("C3 ", "");
				modifiedSentence = modifiedSentence.replaceAll("ACCEPT", " NOW HAS ");
			}
			
			System.out.println(modifiedSentence);	//shows the user modifiedSentence
			clientSocket.close();	//close socket
		}

        
	}
}
