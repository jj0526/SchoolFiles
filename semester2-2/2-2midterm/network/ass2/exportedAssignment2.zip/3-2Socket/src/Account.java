

public class Account {
	public String firstname;
	public int balance;
	Account(String name, int initialValue){
		this.firstname = name;			//saves name to this.firstname
		this.balance = initialValue;	//saves modifiedSentence to this.balance
	}
	public String getName() {
		return firstname;
	}
	public int getbalance() {
		return balance;
	}
	
}