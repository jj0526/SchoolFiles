
public class Bank {
	
	String[] name = new String[] {"Kim", "Choi", "Jo", "Lee", "Park"};
	
	private Account accountObject[] = new Account[5];
	public void setnew() {
		accountObject[0] = new Account(name[0], 500);
		accountObject[1] = new Account(name[1], 700);
		accountObject[2] = new Account(name[2], 200);
		accountObject[3] = new Account(name[3], 300);
		accountObject[4] = new Account(name[4], 400);	//made object array with Account class
	}
	
	public synchronized String check(String customer){
		String clientSentence;
		String capitalizedSentence = null;
		/*when account is found shows the balance information*/
		if(customer.equalsIgnoreCase(accountObject[0].getName())) {	//exact match of the name is found
			clientSentence = "c0 " +customer+ " Account found" + ' ' + "Balance: " + accountObject[0].getbalance();
			capitalizedSentence= clientSentence.toUpperCase() + '\n';	//change the clientSentence to upper case
		}
		else if(customer.equalsIgnoreCase(accountObject[1].getName())) {//exact match of the name is found
			clientSentence = "c0 "+customer+" Account found" + ' ' + "Balance: " + accountObject[1].getbalance();
			capitalizedSentence= clientSentence.toUpperCase() + '\n'; 
				
		}
		else if(customer.equalsIgnoreCase(accountObject[2].getName())) {//exact match of the name is found
			clientSentence = "c0 "+customer+" Account found" + ' ' + "Balance: " + accountObject[2].getbalance();
			capitalizedSentence= clientSentence.toUpperCase() + '\n';
				
		}
		else if(customer.equalsIgnoreCase(accountObject[3].getName())) {//exact match of the name is found
			clientSentence = "c0 "+customer+" Account found" + ' ' + "Balance: " + accountObject[3].getbalance();
			capitalizedSentence= clientSentence.toUpperCase() + '\n';
				
		}
		else if(customer.equalsIgnoreCase(accountObject[4].getName())) {//exact match of the name is found
			clientSentence = "c0 "+customer+" Account found" + ' ' + "Balance: " + accountObject[4].getbalance();
			capitalizedSentence= clientSentence.toUpperCase() + '\n';
				
		}
		else {/*when name is not found*/
			clientSentence = "EXCEPTION: name is not found";	//exception message
			capitalizedSentence= clientSentence.toUpperCase() + '\n';
		}
		return capitalizedSentence;
	}
		public synchronized String deposit(String customer, int amount) {
			String clientSentence;
			String capitalizedSentence = null;
			/*when account is found shows the balance information after adding amount*/
			if(customer.equalsIgnoreCase(accountObject[0].getName())) {//exact match of the name is found
				this.accountObject[0].balance+=amount;
				clientSentence = "c1 "+customer+" Accept" +' ' + "Balance: " + accountObject[0].getbalance();
				capitalizedSentence= clientSentence.toUpperCase() + '\n';	//change the clientSentence to upper case
			}
			else if(customer.equalsIgnoreCase(accountObject[1].getName())) {//exact match of the name is found
				this.accountObject[1].balance+=amount;
				clientSentence = "c1 "+customer+" Accept" +' ' + "Balance: " + accountObject[1].getbalance();
				capitalizedSentence= clientSentence.toUpperCase() + '\n';
			}
			else if(customer.equalsIgnoreCase(accountObject[2].getName())) {//exact match of the name is found
				this.accountObject[2].balance+=amount;
				clientSentence = "c1 "+customer+ " Accept" +' ' + "Balance: " + accountObject[2].getbalance();
				capitalizedSentence= clientSentence.toUpperCase() + '\n';
			}
			else if(customer.equalsIgnoreCase(accountObject[3].getName())) {//exact match of the name is found
				this.accountObject[3].balance+=amount;
				clientSentence = "c1 "+customer+" Accept" +' ' + "Balance: " + accountObject[3].getbalance();
				capitalizedSentence= clientSentence.toUpperCase() + '\n';
			}
			else if(customer.equalsIgnoreCase(accountObject[4].getName())) {//exact match of the name is found
				this.accountObject[4].balance+=amount;
				clientSentence = "c1 "+customer+" Accept" +' ' + "Balance: " + accountObject[4].getbalance();
				capitalizedSentence= clientSentence.toUpperCase() + '\n';
			}
			else {/*customer name is not found*/
				capitalizedSentence = "Exception: "+customer+" is not found";	//exception message
			}
			return capitalizedSentence;	//return capitalizedSentence
			
		}
		public synchronized String withdraw(String customer, int amount) {
			String clientSentence;
			String capitalizedSentence = null;
			/*when account is found shows the balance information after withdrawing amount*/
			if(customer.equalsIgnoreCase(accountObject[0].getName())) {//exact match of the name is found
				if(this.accountObject[0].balance-amount<0) {	//amount can't be withdrawn
					clientSentence = "Exception: The balnce can't go down under 0";	//exception message
					capitalizedSentence= clientSentence.toUpperCase() + '\n';	//change the clientSentence to upper case
				}
				else {//amount can be withdrawn
					this.accountObject[0].balance-=amount;
					clientSentence = "c2 "+customer+" Accept" +' ' + "Balance: " + accountObject[0].getbalance();
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
			}
			else if(customer.equalsIgnoreCase(accountObject[1].getName())) {//exact match of the name is found
				if(this.accountObject[1].balance-amount<0) {	//amount can't be withdrawn
					clientSentence = "Exception: The balnce can't go down under 0";	//exception message
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
				else {//amount can be withdrawn
					this.accountObject[1].balance-=amount;
					clientSentence = "c2 "+customer+" Accept" +' ' + "Balance: " + accountObject[1].getbalance();
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
			}
			else if(customer.equalsIgnoreCase(accountObject[2].getName())) {//exact match of the name is found
				if(this.accountObject[2].balance-amount<0) {	//amount can't be withdrawn
					clientSentence = "Exception: The balnce can't go down under 0";
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
				else {//amount can be withdrawn
					this.accountObject[2].balance-=amount;
					clientSentence = "c2 "+customer+" Accept" +' ' + "Balance: " + accountObject[2].getbalance();
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
			}
			else if(customer.equalsIgnoreCase(accountObject[3].getName())) {//exact match of the name is found
				if(this.accountObject[3].balance-amount<0) {	//amount can't be withdrawn
					clientSentence = "Exception: The balnce can't go down under 0";
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
				else {//amount can be withdrawn
					this.accountObject[3].balance-=amount;
					clientSentence = "c2 "+customer+" Accept" +' ' + "Balance: " + accountObject[3].getbalance();
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
			}
			else if(customer.equalsIgnoreCase(accountObject[4].getName())) {//exact match of the name is found
				if(this.accountObject[4].balance-amount<0) {	//amount can't be withdrawn
					clientSentence = "Exception: The balnce can't go down under 0";
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
				else {//amount can be withdrawn
					this.accountObject[4].balance-=amount;
					clientSentence = "c2 "+customer+" Accept" +' ' + "Balance: " + accountObject[4].getbalance();
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
			}
			else {/*customer name is not found*/
				clientSentence = "EXCEPTION: name is not found";	//exception message
				capitalizedSentence= clientSentence.toUpperCase() + '\n';
			}
			return capitalizedSentence;	//return capitalizedSentence
			
		}
		public synchronized String transfer(String customer1, int amount, String customer2) {
			String clientSentence = null;
			String capitalizedSentence = null;
			System.out.println(customer1 + customer2);
			int cus1 = -1;
			int right = 0;
			/*find customer1's account object*/
			if(customer1.equalsIgnoreCase(customer2)){
				capitalizedSentence = "Exception: You can't transfer to your account";
			}
			if(customer1.equalsIgnoreCase(accountObject[0].getName())) {
				cus1 = 0;
			}
			else if(customer1.equalsIgnoreCase(accountObject[1].getName())) {
				cus1 = 1;
			}
			else if(customer1.equalsIgnoreCase(accountObject[2].getName())) {
				cus1 = 2;
			}
			else if(customer1.equalsIgnoreCase(accountObject[3].getName())) {
				cus1 = 3;
			}
			else if(customer1.equalsIgnoreCase(accountObject[4].getName())) {
				cus1 = 4;
			}
			
			int cus2 = -1;
			
			/*find customer2's account object*/
			if(customer2.equalsIgnoreCase(accountObject[0].getName())) {
				cus2 = 0;
			}
			else if(customer2.equalsIgnoreCase(accountObject[1].getName())) {
				cus2 = 1;
			}
			else if(customer2.equalsIgnoreCase(accountObject[2].getName())) {
				cus2 = 2;
			}
			else if(customer2.equalsIgnoreCase(accountObject[3].getName())) {
				cus2 = 3;
			}
			else if(customer2.equalsIgnoreCase(accountObject[4].getName())) {
				cus2 = 4;
			}
			if (cus1 == -1 && cus2 == -1) {	//none of them was found
				right = -1;
				clientSentence = "Exception: No such info " + customer1 + ", "+ customer2 + " is not found";
			}
			else if (cus1 == -1) {//only customer2 is found
				right = -1;
				clientSentence = "Exception: No such info " + customer1 + " is not found";
			}
			else if (cus2 == -1 ) {//only customer1 is found
				right = -1;
				clientSentence = "Exception: No such info "+ customer2 + " is not found";;
			}
			if (right == 0) {/*found both of them. when account is found shows the balance information after computing*/
				if(this.accountObject[cus1].balance-amount<0) {
					clientSentence = "Exception: The balnce can't go down under 0";	//exception message
					capitalizedSentence= clientSentence.toUpperCase() + '\n';
				}
				else {/*it's able to transfer customer1's balance into customer2's balance*/
					this.accountObject[cus1].balance-=amount;
					this.accountObject[cus2].balance+=amount;
					clientSentence = "C3 "+ accountObject[cus1].firstname+ "Accept " + accountObject[cus1].getbalance()+" " +accountObject[cus2].firstname+" Accept" + "Balance: " 
					+ " " + accountObject[cus2].getbalance();
				}
			}
			capitalizedSentence= clientSentence.toUpperCase() + "\r\n";	//change clientSentence into upper cases
			return capitalizedSentence;
		}
}
