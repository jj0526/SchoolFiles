import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.net.Socket;

public class ClientHandler implements Runnable{
	private final Socket client;
	private final Bank bank;
		
	public ClientHandler(Socket client, Bank bank) {
		this.client = client;	//save client into this.client
		this.bank = bank;		//save bank into this.bank
	}
	@Override
	public void run()  {
		try {
			BufferedReader inFromClient = null;
			DataOutputStream outToClient = null;
			String clientSentence = null;
			String capitalizedSentence = null;
			
			
			inFromClient= new BufferedReader(new
			InputStreamReader(client.getInputStream()));	//create input stream, attached to socket
			
			clientSentence= inFromClient.readLine();	//read in line from the socket
			
			char findChar= ' ';
			int chCount = 0;
			for(int i=0; i<clientSentence.length(); i++) {
			    if(clientSentence.charAt(i) == findChar) {
			          chCount++;}	//counts the number of ' ' in clientSentence
			}
			if(chCount == 0) {//no ' ' in the clientSentence
				capitalizedSentence = "Exception: Wrong command";	//has Exception
			}
			outToClient= new DataOutputStream(client.getOutputStream());	//created output stream, attached to socket
			
		
			String[] parts = clientSentence.split(" ");	//split by " "
			String cmd = parts[0];
			String nameOfUser = null;
			if(chCount!=0) {
				nameOfUser = parts[1].replaceAll("\"", "");	//remove all "s
			}
			String num;
				
			if(cmd.contains("  ")) {	//contains two " "
				capitalizedSentence = "Eception: Wrong command - too much spaces\r\n";	//exception message
			}
				
			if(cmd.equalsIgnoreCase("CHECK")){	//when the word of the message is CHECK
				if(chCount>1) {
					capitalizedSentence = "Exception: Wrong command put CHECK \"NAME\" only";	//exception message
				}
				else {
					if(nameOfUser != null && !nameOfUser.isEmpty()) {	//if nameOfUser is not null and empty
						capitalizedSentence = bank.check(nameOfUser);	//call check function
					}
					else {
						capitalizedSentence = "Exception: lack of arguments\r\n";	//exception message
					}
				}
					
			}
			else if (cmd.equalsIgnoreCase("DEPOSIT")) {	//when the word of the message is DEPOSIT
				if(chCount>2) {
					capitalizedSentence = "Exception: Wrong command put DEPOSIT \"NAME\" AMOUNT only";	//exception message
				}
				else if (chCount==1) {
					capitalizedSentence = "Exception: lack of arguments\r\n";	//exception message
				}
				else {
					num = parts[2];
					if(nameOfUser != null && !nameOfUser.isEmpty() && num!=null && !num.isEmpty()) {
						try {
							int temp = Integer.parseInt(num);	//change num into int and save it into temp
							capitalizedSentence = bank.deposit(nameOfUser, Integer.parseInt(num));	//call deposit function
						}
						catch(NumberFormatException e) {
							capitalizedSentence = "Exception: put an integer";	//exception message
						}
						
					}
					else {
							capitalizedSentence = "Exception: lack of arguments\r\n";	//exception message
					}
				}
				
			}
			else if (cmd.equalsIgnoreCase("WITHDRAW")) {	//when the word of the message is WITHDRAW
				if(chCount>2) {
					capitalizedSentence = "Exception: Wrong command put WITHDRAW \"NAME\" AMOUNT only";	//exception message
				}
				else if (chCount==1) {
					capitalizedSentence = "Exception: lack of arguments\r\n";	//exception message
				}
				else {
					
					num = parts[2];
					if(nameOfUser != null && !nameOfUser.isEmpty() && num!=null && !num.isEmpty()) {
						try {
							int temp = Integer.parseInt(num);	//change num into int and save it into temp
							capitalizedSentence = bank.withdraw(nameOfUser, Integer.parseInt(num));	//call withdraw function
						}
						catch(NumberFormatException e) {
							capitalizedSentence = "Exception: put an integer";	//exception message
						}
					}
					else {
						capitalizedSentence = "Exception: lack of arguments\r\n";	//exception message
					}
				}
			}
			else if (cmd.equalsIgnoreCase("TRANSFER")) {	//when the word of the message is TRANSFER
				if(chCount<=2) {
					capitalizedSentence = "Exception: lack of arguments";	//exception message
				}
				else {
					String part3 = parts[3].replaceAll("\"", "");	//remove all " in the word
					num = parts[2];
					if(nameOfUser != null && !nameOfUser.isEmpty() && num!=null && !num.isEmpty()&&part3 != null && !part3.isEmpty()) {	//when nameOfUser, num and parts3 are not null and empty
						try {
							int temp = Integer.parseInt(num);
							capitalizedSentence = bank.transfer(nameOfUser, Integer.parseInt(num), part3);	//call transfer function
						}
						catch(NumberFormatException e) {
							capitalizedSentence = "Exception: put an integer";	//exception message
						}
					}
					else {
						capitalizedSentence = "Exception: wrong command : put TRANSFER \"name1\" amount \"name2\"\r\n";	//exception message
					}
				}
			}
			else {
				capitalizedSentence = "Exception: Too many arguments or wrong commands\r\n";	//exception message
			}
			capitalizedSentence = capitalizedSentence.toUpperCase() + "\r\n";	//change capitalizedSentence into upper cases
			
			outToClient.writeBytes(capitalizedSentence);	//write out capitalizedSentence to socket
		}
		catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	
	}
}
