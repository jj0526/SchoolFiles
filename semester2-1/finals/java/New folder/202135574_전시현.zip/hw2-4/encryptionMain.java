
public class encryptionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encryption ecp = new encryption();
		ecp.getData();
		ecp.WriteOutput();
	}

}
