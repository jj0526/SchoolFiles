
public class ProfanityMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Profanity pf = new Profanity();
		pf.getData();
		pf.checkString();
	}

}
