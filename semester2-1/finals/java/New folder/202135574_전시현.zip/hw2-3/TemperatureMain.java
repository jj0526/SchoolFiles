
public class TemperatureMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TemperatureList tmpList = new TemperatureList();
		tmpList.getData();
		tmpList.MaxAndMin();
		tmpList.printResult();
	}

}
