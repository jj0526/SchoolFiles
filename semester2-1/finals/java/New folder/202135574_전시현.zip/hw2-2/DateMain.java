
public class DateMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date dt = new Date();
		dt.getData();
		dt.validmonth();
	}

}
